import React, { Component } from 'react'
import TeacherService from '../../services/Teacher'

class ViewTeacher extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            teacher: {}
        }
    }

    componentDidMount() {
        TeacherService.viewTeachers(this.state.id).then(res => {
            this.setState({ teacher: res.data });
        })
    }

    render() {
        return (
            <div>
                <br></br>
                <div className="card col-md-6 offset-md-3">
                    <h3 className="text-center">Teacher Details</h3>
                    <div className="card-body">
                        <div className="row">
                            <label> Teacher First Name: </label>
                            <div> {this.state.teacher.firstName}</div>
                        </div>
                        <div className="row">
                            <label> Teacher Last Name: </label>
                            <div> {this.state.teacher.lastName}</div>
                        </div>
                        <div className="row">
                            <label> Teacher Age: </label>
                            <div> {this.state.teacher.age}</div>
                        </div>
                        <div className="row">
                            <label> Teacher Sex: </label>
                            <div> {this.state.teacher.sex}</div>
                        </div>
                        <div className="row">
                            <label> Teacher Email ID: </label>
                            <div> {this.state.teacher.email}</div>
                        </div>
                        <div className="row">
                            <label> Teacher Address: </label>
                            <div> {this.state.teacher.address}</div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ViewTeacher