import React, { Component } from 'react'
import TeacherService from '../../services/Teacher'

class ListTeacher extends Component {
    constructor(props) {
        super(props)

        this.state = {
            teachers: []
        }
        this.addTeacher = this.addTeacher.bind(this);
        this.editTeacher= this.editTeacher.bind(this);
        this.deleteTeacher= this.deleteTeacher.bind(this);
    }

    deleteTeacher(id) {
        TeacherService.deleteTeacher(id).then(res => {
            console.log(res);
            this.setState({
                teachers: this.state.teachers
                    .filter(teacher => teacher.id !== id)
            });
        });
    }

    viewTeacher(id) {
        window.location.href = window.location.origin + `/view-teacher/${id}`;

    }
    editTeacher(id) {
        window.location.href = window.location.origin + `/add-teacher/${id}`;
    }

    componentDidMount() {
        TeacherService.listTeachers().then((res) => {
            if (res.data == null) {
                this.props.history.push('/add-teacher/_add');
            }
            this.setState({ teachers: res.data });
        });
    }

    addTeacher() {
       window.location.href = window.location.origin + `/add-teacher/_add`;
    }

    render() {
        return (
            <div>
                <h2 className="text-center">Teachers List</h2>
                <div className="row">
                    <button className="btn btn-primary" style={{
          backgroundColor: 'green',
        }}
                        onClick={this.addStudent}> Add Teacher</button>
                </div>
                <br></br>
                <div className="row">
                    <table className="table table-striped table-bordered">

                        <thead>
                            <tr>
                                <th> First Name</th>
                                <th> Last Name</th>
                                <th> Age</th>
                                <th> Sex</th>
                                <th> Email</th>
                                <th> Address</th>
                                <th> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.teachers.map(
                                    teacher =>
                                        <tr key={teacher.id}>
                                            <td> {teacher.firstName} </td>
                                            <td> {teacher.lastName} </td>
                                            <td> {teacher.age}</td>
                                            <td> {teacher.sex}</td>
                                            <td> {teacher.email}</td>
                                            <td> {teacher.address}</td>
                                            <td>
                                                <button onClick={() => this.editTeacher(teacher.id)}
                                                    className="btn btn-info">Update </button>
                                                <button style={{ marginLeft: "10px" }}
                                                    onClick={() => this.deleteTeacher(teacher.id)}
                                                    className="btn btn-danger">Delete </button>
                                                <button style={{ marginLeft: "10px" }}
                                                    onClick={() => this.viewTeacher(teacher.id)}
                                                    className="btn btn-info">View </button>
                                            </td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}

export default ListTeacher