import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
class HeaderComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {

        }
    }

    render() {
        return (
            <div>
                <header>
                    <nav className="navbar navbar-dark bg-primary" >
                        <div><a href="/students" className="navbar-brand" style={{
                            paddingLeft: '100px', paddingRight: '100px',
                        }}>Students Details</a></div>
                        <div><a href="/teachers" className="navbar-brand">Teachers Details</a></div>
                        <div><a href="/courses" className="navbar-brand" style={{
                            paddingRight: '100px', paddingLeft: '100px',
                        }}>Courses Details</a></div>
                    </nav>
                </header>
            </div>
        )
    }
}

export default HeaderComponent