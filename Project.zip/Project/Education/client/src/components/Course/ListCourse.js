import React, { Component } from 'react'
import CourseService from '../../services/Course'

class ListCourse extends Component {
    constructor(props) {
        super(props)

        this.state = {
            courses: []
        }
        this.addCourse = this.addCourse.bind(this);
        this.editCourse = this.editCourse.bind(this);
        this.deleteCourse = this.deleteCourse.bind(this);
    }

    deleteCourse(id) {
        CourseService.deleteCourse(id).then(res => {
            console.log(res);
            this.setState({
                courses: this.state.courses
                    .filter(course => course.id !== id)
            });
        });
    }
    viewCourse(id) {
        window.location.href = window.location.origin + `/view-course/${id}`;

    }
    editCourse(id) {
        window.location.href = window.location.origin + `/add-course/${id}`;
    }

    componentDidMount() {
        CourseService.listCourses().then((res) => {
            console.log(res);
            if (res.data == null) {
                this.props.history.push('/add-course/_add');
            }
            this.setState({ courses: res.data });

        });
    }

    addCourse() {
       window.location.href = window.location.origin + `/add-course/_add`;
    }

    render() {
        return (
            <div>
                <h2 className="text-center">Courses List</h2>
                <div className="row">
                    <button className="btn btn-primary" style={{
          backgroundColor: 'green',
        }}
                        onClick={this.addCourse}> Add Courses</button>
                </div>
                <br></br>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th> Course Id</th>
                                <th> Course Name</th>
                                <th> Students Count</th>
                                <th> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.courses.map(
                                    course =>
                                        <tr key={course.id}>
                                            <td> {course.course_id} </td>
                                            <td> {course.course_name} </td>
                                            <td> {course.student_count}</td>

                                            <td>
                                                <button onClick={() => this.editCourse(course.id)}
                                                    className="btn btn-info">Update </button>
                                                <button style={{ marginLeft: "10px" }}
                                                    onClick={() => this.deleteCourse(course.id)}
                                                    className="btn btn-danger">Delete </button>
                                                <button style={{ marginLeft: "10px" }}
                                                    onClick={() => this.viewCourse(course.id)}
                                                    className="btn btn-info">View </button>
                                            </td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}

export default ListCourse