import React, { Component } from 'react'
import CourseService from '../../services/Course'

class ViewCourse extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            course: {}
        }
    }

    componentDidMount() {
        CourseService.viewCourses(this.state.id).then(res => {
            this.setState({ course: res.data });
        })
    }

    render() {
        return (
            <div>
                <br></br>
                <div className="card col-md-6 offset-md-3">
                    <h3 className="text-center">Course Details</h3>
                    <div className="card-body">
                        <div className="row">
                            <label> Course ID: </label>
                            <div> {this.state.course.course_id}</div>
                        </div>
                        <div className="row">
                            <label> Course Name: </label>
                            <div> {this.state.course.course_name}</div>
                        </div>
                        <div className="row">
                            <label> Student count: </label>
                            <div> {this.state.course.student_count}</div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ViewCourse