import React, { Component } from 'react'
import CourseService from '../../services/Course'

class CreateCourse extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            course_id: '',
            course_name: '',
            student_count: '',
            
        }
        this.changeCourseIdHandler = this
            .changeCourseIdHandler.bind(this);
        this.changeCourseNameHandler = this
            .changeCourseNameHandler.bind(this);
        this.changeStudentsCountHandler = this
            .changeStudentsCountHandler.bind(this);
    }

    componentDidMount() {

        if (this.state.id === '_add') {
            return
        } else {
            CourseService.viewCourses(this.state.id).then((res) => {
                let course = res.data;
                this.setState({
                    course_id: course.course_id,
                    course_name: course.course_name,
                    student_count: course.student_count,
                   
                });
            });
        }
    }
    saveOrUpdateCourse = (e) => {
        
        e.preventDefault();
        let course = {
            course_id: this.state.course_id,
            course_name: this.state.course_name,
            student_count: this.state.student_count,
          
        };
     
        console.log('course => ' + JSON.stringify(course));


        if (this.state.id === '_add') {
            CourseService.createCourse(course).then(res => {
                this.props.history.push('/courses');
            });
        } else {
            CourseService.updateSCourses(course, this.state.id)
                .then(res => {
                    this.props.history.push('/courses');
                });
        }

       window.location.href = window.location.origin + '/courses';
    }

    changeCourseIdHandler = (event) => {
        this.setState({ course_id: event.target.value });
    }

    changeCourseNameHandler = (event) => {
        this.setState({ course_name: event.target.value });
    }

    changeStudentsCountHandler = (event) => {
        this.setState({ student_count: event.target.value });
    }

    cancel() {
        this.props.history.push('/courses');
    }

    getTitle() {
        if (this.state.id === '_add') {
            return <h3 className="text-center">Add Course</h3>
        } else {
            return <h3 className="text-center">Update Course</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3">
                            {
                                this.getTitle()
                            }
                            <div className="card-body">
                                <form>
                                    <div className="form-group">
                                        <label> Course ID: </label>
                                        <input placeholder="Course Id"
                                            name="courseId" className="form-control"
                                            value={this.state.course_id}
                                            onChange={this.changeCourseIdHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label> Course Name: </label>
                                        <input placeholder="Course Name"
                                            name="courseName" className="form-control"
                                            value={this.state.course_name}
                                            onChange={this.changeCourseNameHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label> Students Count: </label>
                                        <input placeholder="studentsCount"
                                            name="studentsCount" className="form-control"
                                            value={this.state.student_count}
                                            onChange={this.changeStudentsCountHandler} />
                                    </div>
                                    <br></br>
                                    <button className="btn btn-success"
                                        onClick={this.saveOrUpdateCourse}>Save</button>

                                    <button className="btn btn-danger"
                                        onClick={this.cancel.bind(this)}
                                        style={{ marginLeft: "10px" }}>Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default CreateCourse