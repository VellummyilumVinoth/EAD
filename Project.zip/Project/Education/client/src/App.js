import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, 
  Switch 
} from 'react-router-dom'
import ListStudent from './components/Student/ListStudent';
import HeaderComponent from './components/Header';
import CreateStudent from './components/Student/CreateStudent';
import ViewStudent from './components/Student/ViewStudent';

import ListTeacher from './components/Teacher/ListTeacher';
import CreateTeacher from './components/Teacher/CreateTeacher';
import ViewTeacher from './components/Teacher/ViewTeacher';

import ListCourse from './components/Course/ListCourse';
import CreateCourse from './components/Course/CreateCourse';
import ViewCourse from './components/Course/ViewCourse';

function App() {
  return (
  <div>
    <Router>
        <HeaderComponent />
        <div className="container">
          <Switch>
          <Route exact path="/students" component={ListStudent}></Route>
            <Route path="/add-student/:id" component={CreateStudent}>
            </Route>
            <Route path="/view-student/:id" component={ViewStudent}>
            </Route>

            <Route exact path="/teachers" component={ListTeacher}></Route>
            <Route path="/add-teacher/:id" component={CreateTeacher}>
            </Route>
            <Route path="/view-teacher/:id" component={ViewTeacher}>
            </Route>

            <Route exact path="/courses" component={ListCourse}></Route>
            <Route path="/add-course/:id" component={CreateCourse}>
            </Route>
            <Route path="/view-course/:id" component={ViewCourse}>
            </Route>

            </Switch>
        </div>
      </Router>
  </div>
      
    

  );
}

export default App;