import axios from 'axios';

const STUDENT_API_BASE_URL = "http://localhost:7070/student";

class Student {

    createStudent(student) {
        return axios.post(STUDENT_API_BASE_URL + '/create/' , student);
    }

    listStudents() {
        return axios.get(STUDENT_API_BASE_URL + '/list');
    }

    viewStudents(studentId) {
        return axios.get(STUDENT_API_BASE_URL + '/view/' + studentId);
    }

    updateStudent(student, studentId) {
        return axios.put(STUDENT_API_BASE_URL + '/update/' + studentId, student);
    }

    deleteStudent(studentId) {
        return axios.delete(STUDENT_API_BASE_URL + '/delete/' + studentId,
    );
    }
}

export default new Student()