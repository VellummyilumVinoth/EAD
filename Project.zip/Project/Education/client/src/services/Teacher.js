import axios from 'axios';

const TEACHER_API_BASE_URL  = "http://localhost:7070/teacher";

class Teacher {

    createTeacher(teacher) {
        return axios.post(TEACHER_API_BASE_URL + '/create/' + teacher);
    }

    listTeachers() {
        return axios.get(TEACHER_API_BASE_URL + '/list');
    }

    viewTeachers(teacherId) {
        return axios.get(TEACHER_API_BASE_URL + '/view/' + teacherId);
    }

    updateTeacher(teacher, teacherId) {
        return axios.put(TEACHER_API_BASE_URL + '/update/' + teacherId, teacher);
    }

    deleteTeacher(teacherId) {
        return axios.delete(TEACHER_API_BASE_URL + '/delete/' + teacherId);
    }
}

export default new Teacher()