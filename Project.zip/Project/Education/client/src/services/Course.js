import axios from 'axios';

const COURSE_API_BASE_URL = "http://localhost:7070/course";

class Course {

    createCourse(course) {
        return axios.post(COURSE_API_BASE_URL + '/create/' , course);
    }

    listCourses() {
        return axios.get(COURSE_API_BASE_URL + '/list');
    }

    viewCourses(coursesId) {
        return axios.get(COURSE_API_BASE_URL + '/view/' + coursesId);
    }

    updateSCourses(course, coursesId) {
        return axios.put(COURSE_API_BASE_URL + '/update/' + coursesId, course);
    }

    deleteCourse(coursesId) {
        return axios.delete(COURSE_API_BASE_URL + '/delete/' + coursesId,
    );
    }
}

export default new Course()