package com.example.server.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "courses")
public class Course {
    @Id
    private String id;

    private String courseId;

    private String courseName;
    private int studentsCount;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getCourse_id() {
        return courseId;
    }

    public void setCourse_id(String course_id) {
        this.courseId = course_id;
    }

    public String getCourse_name() {
        return courseName;
    }

    public void setCourse_name(String course_name) {
        this.courseName = course_name;
    }

    public int getStudent_count() {
        return studentsCount;
    }

    public void setStudent_count(int student_count) {
        this.studentsCount = student_count;
    }

}
