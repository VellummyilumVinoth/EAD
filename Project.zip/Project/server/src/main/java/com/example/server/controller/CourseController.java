package com.example.server.controller;

import com.example.server.exception.ResourceNotFoundException;
import com.example.server.domain.Course;
import com.example.server.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("http://localhost:3000")
@RestController
public class CourseController {
    @Autowired
    private CourseRepository courseRepository;

    @PostMapping("/course/create")
    public Course createCourse(@RequestBody Course course){
        return courseRepository.save(course);
    }

    @GetMapping("/course/list")
    public List<Course> listCourses(){
        return courseRepository.findAll();
    }

    @GetMapping("/course/view/{id}")
    public ResponseEntity<Course> viewCourses(@PathVariable String id){
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException
                        ("Course is not exists with this id :" + id));

        return ResponseEntity.ok(course);
    }

    @PutMapping("/course/update/{id}")
    public ResponseEntity<Course> updateCourse(@PathVariable String id, @RequestBody Course courseDetails){
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException
                        ("Course not exists with this id :" + id));


        course.setStudent_count(courseDetails.getStudent_count());
        course.setCourse_name(courseDetails.getCourse_name());
        course.setCourse_id(courseDetails.getCourse_id());
        Course updatedCourse = courseRepository.save(course);

        return ResponseEntity.ok(updatedCourse);
    }

    @DeleteMapping ("/course/delete/{id}")
    public void deleteCourse(@PathVariable String id){
        courseRepository.deleteById(id);
    }

}

