package com.example.server.controller;

import com.example.server.exception.ResourceNotFoundException;
import com.example.server.domain.Teacher;
import com.example.server.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("http://localhost:3000")
@RestController

public class TeacherController {
    @Autowired
    private TeacherRepository teacherRepository;

    @PostMapping("/teacher/create")
    public Teacher createTeacher(@RequestBody Teacher teacher){
        return teacherRepository.save(teacher);
    }

    @GetMapping("/teacher/list")
    public List<Teacher> listTeachers(){
        return teacherRepository.findAll();
    }

    @GetMapping("/teacher/view/{id}")
    public ResponseEntity<Teacher> viewTeachers(@PathVariable String id){
        Teacher teacher = teacherRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException
                        ("Teacher not exists with this id :" + id));

        return ResponseEntity.ok(teacher);
    }

    @PutMapping("/teacher/update/{id}")
    public ResponseEntity<Teacher> updateTeacher(@PathVariable String id, @RequestBody Teacher teacherDetails){
        Teacher teacher = teacherRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException
                        ("Teacher not exists with this id :" + id));

        teacher.setFirstName(teacherDetails.getFirstName());
        teacher.setLastName(teacherDetails.getLastName());
        teacher.setEmail(teacherDetails.getEmail());
        teacher.setAge(teacherDetails.getAge());
        teacher.setSex(teacherDetails.getSex());
        teacher.setAddress(teacherDetails.getAddress());
        Teacher updatedTeacher = teacherRepository.save(teacher);

        return ResponseEntity.ok(updatedTeacher);
    }

    @DeleteMapping ("/teacher/delete/{id}")
    public void deleteStudent(@PathVariable String id){
        teacherRepository.deleteById(id);
    }
}
