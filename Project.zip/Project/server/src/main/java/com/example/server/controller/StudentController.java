package com.example.server.controller;

import com.example.server.exception.ResourceNotFoundException;
import com.example.server.domain.Student;
import com.example.server.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class StudentController {
    @Autowired
    private StudentRepository studentRepository;

    @PostMapping("/student/create")
    public Student createStudent(@RequestBody Student student){
        return studentRepository.save(student);
    }


    @GetMapping("/student/list")
    public List<Student> listStudents(){
        return studentRepository.findAll();
    }

    @GetMapping("/student/view/{id}")
    public ResponseEntity<Student> viewStudents(@PathVariable String id){
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException
                        ("Student not exists with this id :" + id));

        return ResponseEntity.ok(student);
    }

    @PutMapping("/student/update/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable String id, @RequestBody Student studentDetails){
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException
                        ("Student not exists with this id :" + id));

        student.setFirstName(studentDetails.getFirstName());
        student.setLastName(studentDetails.getLastName());
        student.setEmail(studentDetails.getEmail());
        student.setAge(studentDetails.getAge());
        student.setSex(studentDetails.getSex());
        student.setAddress(studentDetails.getAddress());
        Student updatedStudent = studentRepository.save(student);

        return ResponseEntity.ok(updatedStudent);
    }

    @DeleteMapping ("/student/delete/{id}")
    public void deleteStudent(@PathVariable String id){
        studentRepository.deleteById(id);
    }
}
